import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

const ch = MethodChannel('soundlab/native');
const accent = Color(0xFF8B7CFF);

void main() => runApp(const App());

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.dark,
          scaffoldBackgroundColor: const Color(0xFF0B0B0F),
          colorScheme: const ColorScheme.dark(primary: accent, surface: Color(0xFF15151C)),
          sliderTheme: const SliderThemeData(trackHeight: 3),
        ),
        home: const Home(),
      );
}

final Map<String, double Function(double)> shapes = {
  'Плоский': (x) => 0.0,
  'Бас': (x) => (1 - x) * (1 - x),
  'Вокал': (x) => (1 - ((x - .6).abs() * 3)).clamp(0.0, 1.0).toDouble(),
  'V-образный': (x) => (x - .5).abs() * 2,
  'Высокие': (x) => x * x,
};

class Combo {
  final String n, shape;
  final int bass, loud, virt, room, wet;
  final bool rev;
  const Combo(this.n, this.shape, this.bass, this.loud, this.virt, this.rev, this.room, this.wet);
}

const combos = [
  Combo('Клуб', 'V-образный', 800, 500, 400, false, 0, 0),
  Combo('Концертный зал', 'Плоский', 200, 300, 700, true, 80, 50),
  Combo('Подвал', 'Бас', 600, 200, 300, true, 20, 70),
  Combo('Кинотеатр', 'V-образный', 500, 400, 900, true, 60, 25),
  Combo('Чистый вокал', 'Вокал', 100, 300, 200, false, 0, 0),
];

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _H();
}

class _H extends State<Home> with WidgetsBindingObserver {
  Map<String, dynamic> s = {
    'on': true, 'loud': 0, 'bass': 0, 'virt': 0, 'eq': <int>[],
    'rev': false, 'room': 40, 'wet': 40, 'adv': false, 'mono': false,
  };
  Map<String, dynamic> info = {
    'bands': 5, 'min': -1500, 'max': 1500, 'freqs': [60, 230, 910, 3600, 14000], 'sessions': 0,
  };

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    load();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState st) {
    if (st == AppLifecycleState.resumed) load();
  }

  Future<void> load() async {
    final raw = await ch.invokeMethod<String>('getState') ?? '{}';
    final i = Map<String, dynamic>.from(await ch.invokeMethod('getInfo'));
    final m = Map<String, dynamic>.from(jsonDecode(raw));
    setState(() {
      s = {...s, ...m};
      info = i;
      final n = i['bands'] as int;
      final e = List<int>.from(s['eq'] as List);
      s['eq'] = List<int>.generate(n, (k) => k < e.length ? e[k] : 0);
    });
    if (s['on'] == true) ch.invokeMethod('start');
  }

  void push() {
    setState(() {});
    ch.invokeMethod('apply', jsonEncode(s));
  }

  int g(String k) => (s[k] as num).toInt();
  bool get adv => s['adv'] == true;
  List<int> get eq => s['eq'] as List<int>;

  String fLoud(num v) => adv ? '${(v / 100).toStringAsFixed(1)} dB' : '${(v / 15).round()} %';
  String fStr(num v) => adv ? '${v.round()} / 1000' : '${(v / 10).round()} %';
  String fPct(num v) => '${v.round()} %';
  String fDb(num v) {
    final d = (v / 100).toStringAsFixed(1);
    return v > 0 ? '+$d dB' : '$d dB';
  }

  String fHz(int i) {
    final f = (info['freqs'] as List)[i] as int;
    if (f >= 1000) return '${(f / 1000).toStringAsFixed(f % 1000 == 0 ? 0 : 1)} кГц';
    return '$f Гц';
  }

  void shape(String k, double amt) {
    final n = info['bands'] as int;
    final mx = info['max'] as int;
    final fn = shapes[k]!;
    s['eq'] = List<int>.generate(n, (i) => (fn(n == 1 ? 0.0 : i / (n - 1)) * amt * mx).round());
  }

  Widget sl(String t, num v, num lo, num hi, String Function(num) f, ValueChanged<int> cb) => Column(children: [
        Row(children: [
          Text(t),
          const Spacer(),
          Text(f(v), style: const TextStyle(color: Colors.white60)),
        ]),
        Slider(
          value: v.toDouble().clamp(lo.toDouble(), hi.toDouble()),
          min: lo.toDouble(),
          max: hi.toDouble(),
          onChanged: (x) {
            cb(x.round());
            push();
          },
        ),
      ]);

  Widget card(List<Widget> c) => Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: const Color(0xFF15151C), borderRadius: BorderRadius.circular(18)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: c),
      );

  Widget page(List<Widget> c) => ListView(padding: const EdgeInsets.all(16), children: c);

  @override
  Widget build(BuildContext context) {
    final mn = info['min'] as int, mx = info['max'] as int;
    final n = info['bands'] as int;
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          title: const Text('SoundLab'),
          actions: [
            Switch(
              value: s['on'] == true,
              onChanged: (v) {
                s['on'] = v;
                push();
              },
            ),
            const SizedBox(width: 8),
          ],
          bottom: const TabBar(tabs: [Tab(text: 'Звук'), Tab(text: 'Эквалайзер'), Tab(text: 'Эффекты')]),
        ),
        body: TabBarView(children: [
          page([
            card([
              Text('Подключено плееров: ${info['sessions']}', style: const TextStyle(fontWeight: FontWeight.w600)),
              const SizedBox(height: 4),
              const Text(
                'Эффекты применяются к плеерам, которые сообщают системе свой audio session. Запусти музыку и сверни приложение.',
                style: TextStyle(color: Colors.white54, fontSize: 12),
              ),
            ]),
            card([
              sl('Громкость+', g('loud'), 0, 1500, fLoud, (x) => s['loud'] = x),
              sl('Бас', g('bass'), 0, 1000, fStr, (x) => s['bass'] = x),
              if (eq.isNotEmpty)
                sl('Саб-бас (${fHz(0)})', eq[0], mn, mx, fDb, (x) => eq[0] = x),
              const Text('Большая «Громкость+» может искажать звук и вредить динамикам и слуху.',
                  style: TextStyle(color: Colors.white38, fontSize: 11)),
            ]),
            card([
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Расширенные единицы (dB, 0–1000)'),
                value: adv,
                onChanged: (v) {
                  s['adv'] = v;
                  push();
                },
              ),
            ]),
          ]),
          page([
            card([
              Wrap(spacing: 8, children: [
                for (final k in shapes.keys)
                  ActionChip(
                    label: Text(k),
                    onPressed: () {
                      shape(k, .7);
                      push();
                    },
                  ),
              ]),
            ]),
            card([
              for (var i = 0; i < n && i < eq.length; i++)
                sl(fHz(i), eq[i], mn, mx, fDb, (x) => eq[i] = x),
            ]),
          ]),
          page([
            card([
              const Text('Готовые комбинации', style: TextStyle(fontWeight: FontWeight.w600)),
              const SizedBox(height: 8),
              Wrap(spacing: 8, children: [
                for (final c in combos)
                  ActionChip(
                    label: Text(c.n),
                    onPressed: () {
                      s['bass'] = c.bass;
                      s['loud'] = c.loud;
                      s['virt'] = c.virt;
                      s['rev'] = c.rev;
                      s['room'] = c.room;
                      s['wet'] = c.wet;
                      shape(c.shape, .6);
                      push();
                    },
                  ),
              ]),
            ]),
            card([
              sl('Ширина стерео (Virtualizer)', g('virt'), 0, 1000, fStr, (x) => s['virt'] = x),
            ]),
            card([
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Реверберация'),
                value: s['rev'] == true,
                onChanged: (v) {
                  s['rev'] = v;
                  push();
                },
              ),
              sl('Размер комнаты', g('room'), 0, 100, fPct, (x) => s['room'] = x),
              sl('Уровень эффекта', g('wet'), 0, 100, fPct, (x) => s['wet'] = x),
            ]),
            card([
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Моно звук'),
                value: s['mono'] == true,
                onChanged: (v) async {
                  final ok = await ch.invokeMethod<bool>('setMono', v) ?? false;
                  if (!mounted) return;
                  if (ok) {
                    s['mono'] = v;
                    push();
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Разреши изменение системных настроек и повтори')),
                    );
                  }
                },
              ),
            ]),
          ]),
        ]),
      ),
    );
  }
}
