package com.soundlab.soundlab

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.audiofx.AudioEffect
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.EnvironmentalReverb
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer
import android.net.Uri
import android.provider.Settings
import org.json.JSONObject

private inline fun <T> mk(f: () -> T): T? = try { f() } catch (e: Throwable) { null }

object Engine {
    private var ctx: Context? = null
    private val fx = HashMap<Int, Fx>()
    var state = JSONObject()

    class Fx(val s: Int) {
        val eq = mk { Equalizer(0, s) }
        val bass = mk { BassBoost(0, s) }
        val virt = mk { Virtualizer(0, s) }
        val loud = mk { LoudnessEnhancer(s) }
        val rev = mk { EnvironmentalReverb(0, s) }
        fun release() {
            listOf<AudioEffect?>(eq, bass, virt, loud, rev).forEach { mk { it?.release() } }
        }
    }

    fun init(c: Context) {
        if (ctx != null) return
        ctx = c.applicationContext
        state = JSONObject(prefs().getString("state", "{}") ?: "{}")
    }

    private fun prefs() = ctx!!.getSharedPreferences("fx", 0)
    private fun save() { prefs().edit().putString("state", state.toString()).apply() }

    @Synchronized fun attach(s: Int) {
        if (fx.containsKey(s)) return
        val f = Fx(s); fx[s] = f; apply(f)
    }

    @Synchronized fun detach(s: Int) { fx.remove(s)?.release() }

    @Synchronized fun releaseAll() { fx.values.forEach { it.release() }; fx.clear() }

    @Synchronized fun setState(c: Context, j: JSONObject) {
        init(c); state = j; save()
        fx.values.forEach { apply(it) }
        if (j.optBoolean("on", true)) FxService.start(c)
    }

    fun update(c: Context, f: JSONObject.() -> Unit) {
        init(c)
        val j = JSONObject(state.toString()); j.f(); setState(c, j)
    }

    private fun apply(f: Fx) {
        val on = state.optBoolean("on", true)
        val loud = state.optInt("loud", 0)
        val bass = state.optInt("bass", 0)
        val virt = state.optInt("virt", 0)
        mk { f.loud?.let { it.setTargetGain(loud); it.setEnabled(on && loud > 0) } }
        mk { f.bass?.let { if (it.strengthSupported) it.setStrength(bass.toShort()); it.setEnabled(on && bass > 0) } }
        mk { f.virt?.let { if (it.strengthSupported) it.setStrength(virt.toShort()); it.setEnabled(on && virt > 0) } }
        mk {
            f.eq?.let { e ->
                val arr = state.optJSONArray("eq")
                val lo = e.bandLevelRange[0].toInt(); val hi = e.bandLevelRange[1].toInt()
                for (i in 0 until e.numberOfBands.toInt()) {
                    val v = (arr?.optInt(i, 0) ?: 0).coerceIn(lo, hi)
                    e.setBandLevel(i.toShort(), v.toShort())
                }
                e.setEnabled(on)
            }
        }
        mk {
            f.rev?.let { r ->
                val room = state.optInt("room", 40); val wet = state.optInt("wet", 40)
                r.setDecayTime(300 + room * 40)
                r.setRoomLevel(0.toShort())
                r.setReverbLevel((-9000 + wet * 90).toShort())
                r.setDiffusion(1000.toShort())
                r.setDensity((300 + room * 7).toShort())
                r.setEnabled(on && state.optBoolean("rev", false))
            }
        }
    }

    fun info(c: Context): HashMap<String, Any> {
        val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val m = hashMapOf<String, Any>(
            "sessions" to fx.keys.count { it != 0 }, "bands" to 5, "min" to -1500, "max" to 1500,
            "freqs" to arrayListOf(60, 230, 910, 3600, 14000)
        )
        val e = mk { Equalizer(0, am.generateAudioSessionId()) }
        if (e != null) {
            val n = e.numberOfBands.toInt()
            m["bands"] = n
            m["min"] = e.bandLevelRange[0].toInt()
            m["max"] = e.bandLevelRange[1].toInt()
            m["freqs"] = ArrayList((0 until n).map { e.getCenterFreq(it.toShort()) / 1000 })
            e.release()
        }
        return m
    }

    fun setMono(c: Context, on: Boolean): Boolean {
        if (!Settings.System.canWrite(c)) {
            c.startActivity(
                Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${c.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return false
        }
        return mk { Settings.System.putInt(c.contentResolver, "master_mono", if (on) 1 else 0) } ?: false
    }
}
