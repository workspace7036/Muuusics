package com.soundlab.soundlab

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.widget.RemoteViews

class FxWidget : AppWidgetProvider() {
    companion object {
        const val UP = "sl.UP"
        const val DOWN = "sl.DOWN"
        const val BASS = "sl.BASS"
    }

    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        for (id in ids) m.updateAppWidget(id, views(c))
    }

    override fun onReceive(c: Context, i: Intent) {
        super.onReceive(c, i)
        Engine.init(c)
        val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val st = AudioManager.STREAM_MUSIC
        when (i.action) {
            UP -> if (am.getStreamVolume(st) < am.getStreamMaxVolume(st))
                am.adjustStreamVolume(st, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            else Engine.update(c) { put("on", true); put("loud", minOf(1500, optInt("loud") + 250)) }
            DOWN -> if (Engine.state.optInt("loud") > 0)
                Engine.update(c) { put("loud", maxOf(0, optInt("loud") - 250)) }
            else am.adjustStreamVolume(st, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            BASS -> Engine.update(c) {
                val b = optInt("bass")
                put("on", true)
                put("bass", when { b < 300 -> 400; b < 600 -> 700; b < 900 -> 1000; else -> 0 })
            }
        }
    }

    private fun views(c: Context): RemoteViews {
        val v = RemoteViews(c.packageName, R.layout.widget)
        v.setOnClickPendingIntent(R.id.vdown, pi(c, DOWN))
        v.setOnClickPendingIntent(R.id.vup, pi(c, UP))
        v.setOnClickPendingIntent(R.id.bass, pi(c, BASS))
        return v
    }

    private fun pi(c: Context, a: String) = PendingIntent.getBroadcast(
        c, a.hashCode(), Intent(c, FxWidget::class.java).setAction(a),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
}
