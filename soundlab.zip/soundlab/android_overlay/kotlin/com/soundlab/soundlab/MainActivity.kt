package com.soundlab.soundlab

import android.Manifest
import android.os.Build
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import org.json.JSONObject

class MainActivity : FlutterActivity() {
    override fun configureFlutterEngine(fe: FlutterEngine) {
        super.configureFlutterEngine(fe)
        Engine.init(this)
        MethodChannel(fe.dartExecutor.binaryMessenger, "soundlab/native").setMethodCallHandler { call, res ->
            when (call.method) {
                "getState" -> res.success(Engine.state.toString())
                "apply" -> { Engine.setState(this, JSONObject(call.arguments as String)); res.success(null) }
                "getInfo" -> res.success(Engine.info(this))
                "setMono" -> res.success(Engine.setMono(this, call.arguments as Boolean))
                "start" -> { FxService.start(this); res.success(null) }
                else -> res.notImplemented()
            }
        }
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }
}
