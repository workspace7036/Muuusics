package com.soundlab.soundlab

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.media.audiofx.AudioEffect
import android.os.Build
import android.os.IBinder
import androidx.core.content.ContextCompat

class SessionReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val s = i.getIntExtra(AudioEffect.EXTRA_AUDIO_SESSION, -1)
        if (s < 0) return
        Engine.init(c)
        if (i.action == AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION) Engine.attach(s) else Engine.detach(s)
    }
}

class FxService : Service() {
    private val rcv = SessionReceiver()

    companion object {
        fun start(c: Context) {
            try { ContextCompat.startForegroundService(c, Intent(c, FxService::class.java)) } catch (e: Throwable) {}
        }
    }

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int = START_STICKY

    override fun onCreate() {
        super.onCreate()
        Engine.init(this)
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(NotificationChannel("fx", "Sound effects", NotificationManager.IMPORTANCE_LOW))
        }
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "fx") else Notification.Builder(this)
        val n = b.setContentTitle("SoundLab").setContentText("Эффекты активны")
            .setSmallIcon(android.R.drawable.ic_media_play).setContentIntent(pi).setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
        val f = IntentFilter().apply {
            addAction(AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION)
            addAction(AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION)
        }
        ContextCompat.registerReceiver(this, rcv, f, ContextCompat.RECEIVER_EXPORTED)
        Engine.attach(0)
    }

    override fun onDestroy() {
        try { unregisterReceiver(rcv) } catch (e: Throwable) {}
        Engine.releaseAll()
        super.onDestroy()
    }
}
